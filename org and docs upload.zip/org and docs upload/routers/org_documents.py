
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, Response, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from db import get_session
from models import Organization, SubOrganization, Domain, OrgDocument
from schemas import OrgDocumentOut

router = APIRouter(prefix="/org-documents", tags=["org_documents"])

MAX_SIZE = 20 * 1024 * 1024  # 20 MB

@router.post("", response_model=OrgDocumentOut, status_code=201)
async def upload_org_document(
    org_id: int = Form(...),
    suborg_id: int = Form(...),
    domain_id: int = Form(...),
    user_id: int | None = Form(default=None),
    file: UploadFile = File(...),
    session: AsyncSession = Depends(get_session)
):
    # Validate hierarchy
    org = await session.get(Organization, org_id)
    sub = await session.get(SubOrganization, suborg_id)
    dom = await session.get(Domain, domain_id)
    if not org or not sub or not dom or sub.org_id != org_id or dom.suborg_id != suborg_id:
        raise HTTPException(status_code=400, detail="Invalid org/suborg/domain relationship")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty file")
    if len(data) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large")

    doc = OrgDocument(
        org_id=org_id,
        suborg_id=suborg_id,
        domain_id=domain_id,
        user_id=user_id,
        filename=file.filename,
        mimetype=file.content_type or "application/octet-stream",
        size_bytes=len(data),
        file_bytes=data,
        content_text=None
    )
    session.add(doc)
    await session.commit()
    await session.refresh(doc)
    return doc

@router.get("", response_model=list[OrgDocumentOut])
async def list_org_documents(
    org_id: int | None = Query(default=None),
    suborg_id: int | None = Query(default=None),
    domain_id: int | None = Query(default=None),
    session: AsyncSession = Depends(get_session)
):
    q = select(OrgDocument)
    if org_id is not None:
        q = q.where(OrgDocument.org_id == org_id)
    if suborg_id is not None:
        q = q.where(OrgDocument.suborg_id == suborg_id)
    if domain_id is not None:
        q = q.where(OrgDocument.domain_id == domain_id)
    res = await session.execute(q.order_by(OrgDocument.doc_id.desc()))
    return res.scalars().all()

@router.get("/{doc_id}/download")
async def download_org_document(doc_id: int, session: AsyncSession = Depends(get_session)):
    doc = await session.get(OrgDocument, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return Response(
        content=doc.file_bytes,
        media_type=doc.mimetype or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{doc.filename}"'}
    )
