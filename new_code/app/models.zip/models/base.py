# Single source of truth for Base
from sqlalchemy.orm import declarative_base
Base = declarative_base()
